var APP_DATA = {
  "scenes": [
    {
      "id": "0-street-view-360",
      "name": "Street View 360",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1664,
      "initialViewParameters": {
        "yaw": 2.6291393276436335,
        "pitch": 0.035083446310007815,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": -2.2745689029078395,
          "pitch": -0.05854894062231786,
          "title": "廁所",
          "text": "<br>"
        }
      ]
    }
  ],
  "name": "PIPE ENTRY",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
